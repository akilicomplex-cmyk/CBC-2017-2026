import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Kenya CBC Historical Dashboard",page_icon="🇰🇪",layout="wide")
@st.cache_data
def load():
    return pd.read_csv("cbc_historical_student_data_2017_2026.csv")
df=load()
st.title("🇰🇪 Kenya CBC Historical Student Analytics")
st.caption("Synthetic demonstration dataset covering 2017–2026; not official Ministry, KICD, KNEC, or school records.")

st.sidebar.header("Dashboard Filters")
years=st.sidebar.slider("Year",int(df.year.min()),int(df.year.max()),(2017,2026))
counties=st.sidebar.multiselect("County",sorted(df.county.unique()),default=sorted(df.county.unique()))
grades=st.sidebar.multiselect("Grade",list(df.grade.unique()),default=list(df.grade.unique()))
types=st.sidebar.multiselect("School Type",list(df.school_type.unique()),default=list(df.school_type.unique()))
genders=st.sidebar.multiselect("Gender",list(df.gender.unique()),default=list(df.gender.unique()))
d=df[df.year.between(*years)&df.county.isin(counties)&df.grade.isin(grades)&df.school_type.isin(types)&df.gender.isin(genders)]

a,b,c,e=st.columns(4)
a.metric("Learner Records",len(d))
b.metric("Average Score",f"{d.overall_score.mean():.1f}" if len(d) else "N/A")
c.metric("Attendance",f"{d.attendance_rate.mean():.1f}%" if len(d) else "N/A")
e.metric("Score ≥ 60",f"{(d.overall_score.ge(60).mean()*100):.1f}%" if len(d) else "N/A")
st.divider()

l,r=st.columns(2)
with l:
 st.subheader("Average Score Trend")
 trend=d.groupby("year",as_index=False).overall_score.mean()
 st.plotly_chart(px.line(trend,x="year",y="overall_score",markers=True),use_container_width=True)
with r:
 st.subheader("Learner Records by Grade")
 g=d.grade.value_counts().reindex(grades,fill_value=0).reset_index()
 g.columns=["grade","count"]
 st.plotly_chart(px.bar(g,x="grade",y="count"),use_container_width=True)

l,r=st.columns(2)
with l:
 st.subheader("Learning Area Profile")
 areas=["literacy","numeracy","communication","creativity","collaboration"]
 av=d[areas].mean().reset_index()
 av.columns=["learning_area","average_score"]
 st.plotly_chart(px.bar(av,x="learning_area",y="average_score",range_y=[0,100],text_auto=".1f"),use_container_width=True)
with r:
 st.subheader("County Comparison")
 co=d.groupby("county",as_index=False).overall_score.mean().sort_values("overall_score",ascending=False)
 st.plotly_chart(px.bar(co,x="county",y="overall_score",range_y=[0,100],text_auto=".1f"),use_container_width=True)

st.subheader("Performance Level Distribution")
p=d.performance_level.value_counts().reindex(["Below Expectations","Approaching Expectations","Meeting Expectations","Exceeding Expectations"],fill_value=0).reset_index()
p.columns=["performance_level","count"]
st.plotly_chart(px.bar(p,x="performance_level",y="count"),use_container_width=True)

st.subheader("Attendance and Performance")
st.plotly_chart(px.scatter(d,x="attendance_rate",y="overall_score",color="school_type",hover_data=["year","county","grade"]),use_container_width=True)

st.subheader("Filtered Data")
st.dataframe(d,use_container_width=True,hide_index=True)
st.download_button("Download Filtered CSV",d.to_csv(index=False),"filtered_cbc_data.csv","text/csv")

# Kenya CBC Historical Student Dashboard (2017–2026)

## Project overview
An interactive Streamlit dashboard that demonstrates historical-style analysis of Kenya's Competency-Based Curriculum (CBC) using synthetic learner records.

## Included
- 2,500 synthetic learner records across 2017–2026
- Filters for year, county, grade, school type, and gender
- Trend analysis, learning-area analysis, county comparisons, performance levels, attendance relationships
- CSV download

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## GitHub deployment
Upload all files to a GitHub repository, then deploy `app.py` through Streamlit Community Cloud.

## Data and ethics
The dataset is synthetic and does not describe real learners. Do not upload identifiable learner records to a public repository. For real use, apply authorization, anonymization, access controls, and Kenya's applicable data-protection requirements.

## Historical context
KICD documentation describes trials in 2017, national piloting in 2018, and national rollout in 2019, followed by progressive implementation. Confirm current curriculum terminology and grade structures against official KICD and Ministry of Education publications before using the dashboard for research.
